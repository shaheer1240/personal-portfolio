# Shaheer — Personal Portfolio

A premium, production-ready personal portfolio website built with React, Vite, TypeScript, Tailwind CSS, and Framer Motion.

## ✨ Features

- **Dark premium theme** with glassmorphism, gradients, and animated spotlight effects
- **Particle field background** with dynamic connections
- **Custom cursor** with spring-physics trailing ring
- **Loading screen** with animated progress
- **Smooth scroll** powered by Lenis
- **Scroll progress bar** at the top of the page
- **Command palette** (Ctrl+K / ⌘K) for quick navigation
- **Animated section reveals** using Intersection Observer
- **Back to top** button
- **Responsive** — mobile-first, works on all screen sizes
- **Accessible** — semantic HTML, ARIA labels, keyboard navigation, focus states
- **SEO optimized** — Open Graph, Twitter cards, structured data
- **Contact form** with EmailJS integration

## 🧱 Tech Stack

| Category | Technology |
|----------|------------|
| Framework | React 18 + Vite |
| Language | TypeScript |
| Styling | Tailwind CSS |
| Animations | Framer Motion |
| Smooth Scroll | Lenis |
| Icons | Lucide React |
| Email | EmailJS |

## 🚀 Quick Start

### 1. Clone & Install

```bash
git clone <repo-url>
cd shaheer-portfolio
npm install
```

### 2. Set up Environment Variables

```bash
cp .env.example .env
```

Edit `.env` with your EmailJS credentials (see EmailJS Setup below).

### 3. Run Development Server

```bash
npm run dev
```

Open `http://localhost:5173`

### 4. Build for Production

```bash
npm run build
```

Output is in `./dist`

## 📧 EmailJS Setup

1. Sign up at [emailjs.com](https://www.emailjs.com)
2. Create an **Email Service** (Gmail, Outlook, etc.) → get your **Service ID**
3. Create an **Email Template** with these variables:
   - `{{from_name}}` — sender's name
   - `{{from_email}}` — sender's email
   - `{{subject}}` — message subject
   - `{{message}}` — message body
   - `{{to_name}}` — your name (Shaheer)
4. Get your **Public Key** from Account → API Keys
5. Add to your `.env`:

```
VITE_EMAILJS_SERVICE_ID=service_xxxxxxx
VITE_EMAILJS_TEMPLATE_ID=template_xxxxxxx
VITE_EMAILJS_PUBLIC_KEY=xxxxxxxxxxxxxxx
```

## 🌐 Netlify Deployment

### Option A: Drag & Drop

1. Run `npm run build`
2. Drag the `dist/` folder to [app.netlify.com/drop](https://app.netlify.com/drop)

### Option B: Git Integration (recommended)

1. Push code to GitHub
2. Go to [netlify.com](https://netlify.com) → **New site from Git**
3. Select your repo
4. Set build command: `npm run build`
5. Set publish directory: `dist`
6. Add environment variables in **Site settings → Environment variables**
7. Deploy!

The `netlify.toml` handles all redirect and cache configuration automatically.

## 📁 Project Structure

```
src/
├── components/
│   ├── layout/
│   │   ├── Navbar.tsx        # Fixed navigation with mobile menu
│   │   └── Footer.tsx        # Site footer
│   ├── sections/
│   │   ├── HeroSection.tsx   # Full-screen hero with typewriter
│   │   ├── AboutSection.tsx  # About + stats + traits
│   │   ├── SkillsSection.tsx # Skills with animated progress bars
│   │   ├── ProjectsSection.tsx  # Projects with expandable case studies
│   │   ├── EducationSection.tsx # Education + certifications
│   │   └── ContactSection.tsx   # Contact form with EmailJS
│   └── ui/
│       ├── CustomCursor.tsx  # Dot + ring cursor
│       ├── LoadingScreen.tsx # Intro loading animation
│       ├── ParticleField.tsx # Canvas particle background
│       ├── ScrollProgressBar.tsx
│       ├── CommandPalette.tsx  # Ctrl+K command menu
│       ├── BackToTop.tsx
│       ├── RevealSection.tsx   # Scroll-triggered reveal wrapper
│       └── SectionHeader.tsx   # Reusable section titles
├── data/
│   └── cv.ts                 # All content from CV — single source of truth
├── hooks/
│   ├── useSmoothScroll.ts    # Lenis integration
│   ├── useScrollProgress.ts
│   └── useInView.ts          # Intersection observer hook
├── App.tsx
├── main.tsx
└── index.css                 # Global styles + utilities
```

## ♿ Accessibility

- Semantic HTML5 landmarks
- Proper heading hierarchy (h1 → h2 → h3)
- ARIA labels on interactive elements
- Keyboard navigation for all interactive components
- Visible focus states
- Reduced motion support (`prefers-reduced-motion`)
- Sufficient color contrast ratios

## 🎨 Customization

All content lives in `src/data/cv.ts`. Update that file to change any text, projects, skills, or contact information — the UI updates automatically.

To change the color scheme, update the CSS variables in `src/index.css` and the Tailwind config in `tailwind.config.js`.

## 📄 License

MIT — feel free to use as a template for your own portfolio.
