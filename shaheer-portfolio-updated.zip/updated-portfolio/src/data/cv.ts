// src/data/cv.ts
// Single source of truth — updated from Shaheer's latest resume

export const personal = {
  name: 'Shaheer',
  fullName: 'Shaheer Uzair',
  title: 'Aspiring .NET MVC & Cross-Platform Developer',
  tagline: 'Building user-focused digital experiences',
  location: 'Karachi, Sindh, Pakistan',
  email: 'shaheeruzair64@gmail.com',
  portfolio: 'https://show-my-work-1.preview.emergentagent.com',
  linkedin: 'https://www.linkedin.com/in/shaheer-uzair-145246383/',
  github: 'https://github.com/shaheer1240',
  indeed: 'https://profile.indeed.com/?hl=en_PK&co=PK&from=gnav-homepage',
  languages: [
    { name: 'English', level: 'Professional' },
    { name: 'Urdu', level: 'Native' },
  ],
  interests: ['Web Development', 'Open Source Contribution', 'UI/UX Design', 'Mobile App Development', 'Learning New Technologies'],
  summary:
    "Dedicated O-Level student and developer with strong proficiency in ASP.NET MVC and C#, solid frontend skills in HTML5, CSS3, Bootstrap 5, and JavaScript, and growing backend expertise in PHP, SQL, and MySQL. Currently advancing in cross-platform mobile development with Flutter and Firebase. Hafiz-e-Quran with strong discipline and consistency. Experienced across 10+ academic and professional projects, passionate about building user-focused, database-driven applications.",
}

export const experience = [
  {
    role: 'PHP Developer',
    company: 'Innova Tech',
    period: 'Professional Experience',
    bullets: [
      'Contributed to 5–6 client and company projects as a PHP developer',
      'Developed dynamic, database-driven web applications using PHP and MySQL',
      'Collaborated within a software house environment using Agile workflows and Git-based version control',
      'Worked on backend logic, database integration, and feature implementation across multiple projects',
    ],
  },
]

export const skills = {
  frontend: [
    { name: 'HTML5 & CSS3', level: 90 },
    { name: 'Bootstrap 5', level: 87 },
    { name: 'JavaScript (Expert)', level: 85 },
    { name: 'React.js & Tailwind CSS', level: 78 },
    { name: 'Responsive Design', level: 88 },
  ],
  backend: [
    { name: 'ASP.NET MVC & C#', level: 82 },
    { name: 'PHP', level: 80 },
    { name: 'RESTful APIs', level: 74 },
    { name: 'Session Auth & CRUD', level: 82 },
  ],
  database: [
    { name: 'MySQL', level: 82 },
    { name: 'SQL Server', level: 80 },
    { name: 'MongoDB (Learning)', level: 40 },
  ],
  tools: [
    { name: 'Figma / UI Design', level: 78 },
    { name: 'Git & Version Control', level: 80 },
    { name: 'Agile Methodology', level: 76 },
    { name: 'Problem Solving', level: 90 },
  ],
  learning: ['Flutter (~50%)', 'Firebase (~70%)', 'MongoDB', 'Node.js'],
}

export const projects = [
  {
    id: 'focusflow',
    title: 'FocusFlow',
    subtitle: 'Productivity App — Currently Building',
    description:
      'A productivity software application for analyzing and helping users maintain focus — tracking sessions, generating analytics, and helping users understand their concentration patterns.',
    problem:
      'Developers and students struggle to measure and improve their focus in an increasingly distracted world. Existing tools lack meaningful analytics.',
    objectives: [
      'Design a robust MVC architecture for tracking focus sessions',
      'Build an analytics dashboard for visualizing concentration data',
      'Create a clean, distraction-free UI for the end user',
      'Implement SQL Server schema for historical data persistence',
    ],
    technologies: ['ASP.NET MVC', 'C#', 'SQL Server', 'HTML5', 'CSS3', 'JavaScript'],
    features: [
      'Focus session tracking with configurable timers',
      'Analytics dashboard showing focus trends over time',
      'User progress reports and session history',
      'MVC architecture for clean separation of concerns',
      'SQL Server backend for reliable data persistence',
    ],
    challenges: [
      'Designing a data model that captures meaningful focus metrics',
      'Building real-time session tracking without page refreshes',
    ],
    solutions: [
      'Designed a normalized schema with session, analytics, and user tables',
      'Used JavaScript timers with AJAX calls for seamless session recording',
    ],
    learnings: [
      'Deep dive into ASP.NET MVC architecture and patterns',
      'Data-driven design thinking for productivity applications',
      'Importance of UX in tools meant to reduce distraction',
    ],
    impact: 'Flagship project showcasing ASP.NET MVC expertise and commitment to building practical, user-centered software.',
    color: '#00D4FF',
    icon: '🎯',
    status: 'in-progress',
    featured: true,
    githubUrl: 'https://github.com/shaheer1240',
    liveUrl: null,
  },
  {
    id: 'talent-platform',
    title: 'Talent Showcasing Platform',
    subtitle: 'ASP.NET MVC Talent Marketplace',
    description:
      'A web platform enabling individuals to create talent profiles, submit multimedia showcases, and be discovered via advanced search and filtering — built with ASP.NET MVC and SQL Server.',
    problem:
      'Aspiring creators lacked a centralized platform to present their talents digitally, making discovery by opportunity providers difficult.',
    objectives: [
      'Enable rich multimedia talent profiles with video and image uploads',
      'Build powerful search and filter capabilities by category and skill',
      'Ensure modular, maintainable codebase using MVC patterns',
      'Optimize media storage and retrieval performance',
    ],
    technologies: ['ASP.NET MVC', 'C#', 'SQL Server', 'HTML5', 'CSS3'],
    features: [
      'Talent submission with multimedia upload support',
      'Profile management with robust input validation',
      'Advanced search and filter by category and skills',
      'Optimized image and video compression pipeline',
      'SQL Server integration for efficient data retrieval',
    ],
    challenges: [
      'Handling multimedia uploads efficiently without degrading performance',
      'Designing flexible search queries across multiple talent categories',
    ],
    solutions: [
      'Implemented server-side compression and storage optimization for uploads',
      'Used parameterized SQL queries with indexed columns for fast search',
    ],
    learnings: [
      'Mastery of MVC architecture for scalable application structure',
      'Practical experience with C# and .NET ecosystem',
      'Understanding of media handling in web applications',
    ],
    impact: 'Showcased ability to build complex, data-driven platforms with professional architecture.',
    color: '#8B5CF6',
    icon: '🎭',
    status: 'completed',
    featured: false,
    githubUrl: 'https://github.com/shaheer1240',
    liveUrl: null,
  },
  {
    id: 'grocery-cart',
    title: 'PHP Dynamic Cart System',
    subtitle: 'Full-Stack PHP E-Commerce',
    description:
      'A dynamic shopping cart system with individual product management, secure authentication, order tracking, and a full admin panel — built with PHP and MySQL from scratch.',
    problem:
      'Small businesses needed an affordable, customizable online storefront with real inventory control and order management.',
    objectives: [
      'Build a responsive, user-friendly shopping experience',
      'Implement secure authentication and session management',
      'Create a robust admin panel for business owners',
      'Design a scalable database architecture',
    ],
    technologies: ['PHP', 'MySQL', 'HTML5', 'CSS3', 'JavaScript'],
    features: [
      'Dynamic shopping cart with individual product management',
      'Secure user authentication with session handling',
      'Real-time order tracking for customers',
      'Admin panel with inventory & sales analytics',
      'Responsive UI optimized for all devices',
    ],
    challenges: [
      'Designing a normalized database schema for products, users, and orders',
      'Implementing secure session management to prevent unauthorized access',
    ],
    solutions: [
      'Used relational database design with foreign key constraints for data integrity',
      'Implemented PHP session tokens with CSRF protection patterns',
    ],
    learnings: [
      'Deep understanding of server-side scripting with PHP',
      'Appreciation for database normalization and query optimization',
      'Importance of security-first thinking in web applications',
    ],
    impact: 'Demonstrated ability to architect and ship a complete, production-ready web application independently.',
    color: '#10B981',
    icon: '🛒',
    status: 'completed',
    featured: false,
    githubUrl: 'https://github.com/shaheer1240',
    liveUrl: null,
  },
  {
    id: 'laptop-ecommerce',
    title: 'Laptop E-Commerce App',
    subtitle: 'Flutter & Firebase Mobile App',
    description:
      'A cross-platform mobile e-commerce application for laptops built with Flutter, integrating Firebase for authentication, real-time database, and cloud storage.',
    problem:
      'Mobile shoppers needed a fast, native-feeling app for browsing and purchasing laptops with real-time inventory updates.',
    objectives: [
      'Build a cross-platform app targeting both iOS and Android',
      'Implement Firebase Auth for secure user onboarding',
      'Use Firestore for real-time product and order data',
      'Design an intuitive mobile-first shopping experience',
    ],
    technologies: ['Flutter', 'Firebase', 'Dart', 'Firestore', 'Firebase Auth'],
    features: [
      'Cross-platform support for iOS and Android',
      'Firebase Authentication for secure login',
      'Real-time product listings via Firestore',
      'Cloud Storage for product imagery',
      'Cart and order management on-device',
    ],
    challenges: [
      'Synchronizing real-time data efficiently without unnecessary reads',
      'Building a responsive UI that works across screen sizes',
    ],
    solutions: [
      'Used Firestore listeners with targeted queries to minimize data usage',
      'Applied Flutter responsive layout techniques with MediaQuery',
    ],
    learnings: [
      'Practical Flutter widget system and state management',
      'Firebase ecosystem integration (Auth, Firestore, Storage)',
      'Cross-platform UI design considerations',
    ],
    impact: 'Demonstrated ability to build modern mobile apps while advancing Flutter and Firebase expertise.',
    color: '#F59E0B',
    icon: '📱',
    status: 'in-progress',
    featured: false,
    githubUrl: 'https://github.com/shaheer1240',
    liveUrl: null,
  },
  {
    id: 'portfolio',
    title: 'Personal Portfolio Website',
    subtitle: 'React.js & Tailwind CSS',
    description:
      'A personal portfolio website showcasing projects and skills, built with React.js and Tailwind CSS for a responsive, modern UI.',
    problem:
      'Needed a professional online presence to showcase technical work to recruiters and collaborators.',
    objectives: [
      'Create a visually impressive, recruiter-friendly portfolio',
      'Showcase projects with rich case study detail',
      'Ensure full responsiveness across all devices',
      'Maintain fast load times and smooth interactions',
    ],
    technologies: ['React.js', 'Tailwind CSS', 'TypeScript', 'Framer Motion', 'Vite'],
    features: [
      'Smooth scroll with animated section transitions',
      'Custom cursor and particle background effects',
      'Command palette for rapid navigation',
      'Fully responsive mobile-first design',
      'Project case studies with expandable detail',
    ],
    challenges: [
      'Balancing visual richness with performance',
      'Organizing complex project data in a maintainable structure',
    ],
    solutions: [
      'Used lazy loading and optimized animations for 60fps performance',
      'Centralized all data in a single cv.ts source of truth',
    ],
    learnings: [
      'Advanced React patterns and TypeScript typing',
      'Animation and micro-interaction design with Framer Motion',
      'Performance optimization for visual-heavy applications',
    ],
    impact: 'A living showcase of design and development skills, actively used to land opportunities.',
    color: '#3B82F6',
    icon: '🌐',
    status: 'completed',
    featured: false,
    githubUrl: 'https://github.com/shaheer1240',
    liveUrl: 'https://show-my-work-1.preview.emergentagent.com',
  },
  {
    id: 'sports-info',
    title: 'Sports Info Frontend',
    subtitle: 'HTML, CSS & JavaScript',
    description:
      'A sports information website with an interactive, user-focused frontend UI/UX featuring responsive layouts and dynamic content.',
    problem:
      'Sports fans needed a clean, fast interface to browse team and match information without clutter.',
    objectives: [
      'Build an engaging, responsive sports information UI',
      'Implement dynamic content rendering with vanilla JavaScript',
      'Ensure accessibility and cross-browser compatibility',
    ],
    technologies: ['HTML5', 'CSS3', 'JavaScript'],
    features: [
      'Interactive sports data display with dynamic filtering',
      'Responsive layout for desktop and mobile',
      'Smooth CSS animations and transitions',
      'Clean, modern sports-themed design language',
    ],
    challenges: [
      'Creating engaging interactivity using only vanilla JavaScript',
    ],
    solutions: [
      'Leveraged DOM manipulation and CSS transitions for rich UX without frameworks',
    ],
    learnings: [
      'Deep mastery of vanilla JS DOM APIs',
      'CSS animation techniques without library overhead',
    ],
    impact: 'Proved strong frontend fundamentals before moving to framework-based development.',
    color: '#EC4899',
    icon: '⚽',
    status: 'completed',
    featured: false,
    githubUrl: 'https://github.com/shaheer1240',
    liveUrl: null,
  },
]

export const education = [
  {
    degree: 'O-Level',
    institution: 'Currently Studying',
    location: 'Karachi, Pakistan',
    description:
      'Pursuing O-Level education while simultaneously developing practical software development skills through Aptech training and real-world projects.',
  },
  {
    degree: 'CPSIM, DPISM, HDSE — Web Development',
    institution: 'Aptech Computer Education',
    location: 'Karachi, Pakistan',
    description:
      'Comprehensive program covering the full spectrum of web development — from frontend fundamentals to backend architecture and database management.',
  },
]

export const certifications = [
  {
    title: 'UI/UX Design Certification',
    subtitle: 'Recently Obtained',
    issuer: 'Professional Certification',
    description: 'Certification validating expertise in user interface design, prototyping, and user experience principles using Figma.',
  },
  {
    title: 'Aptech Certified Software & Web Developer',
    subtitle: 'CPSIM, DPISM, HDSE',
    issuer: 'Aptech Computer Education',
    description: 'Industry-recognized certification validating expertise in software and web development.',
  },
  {
    title: 'Hafiz-e-Quran',
    subtitle: 'Personal Achievement',
    issuer: 'Islamic Studies',
    description: 'Memorization of the complete Holy Quran — a testament to discipline, consistency, and extraordinary focus.',
  },
  {
    title: 'Agile Development Methodologies',
    subtitle: 'Professional Proficiency',
    issuer: 'Aptech Computer Education & Project Experience',
    description: 'Proficient in Agile workflows, sprint planning, and collaborative team development practices.',
  },
]
