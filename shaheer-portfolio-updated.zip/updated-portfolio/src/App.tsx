import { useEffect, useState } from 'react'
import { useSmoothScroll } from '@/hooks/useSmoothScroll'
import LoadingScreen from '@/components/ui/LoadingScreen'
import Navbar from '@/components/layout/Navbar'
import Footer from '@/components/layout/Footer'
import ScrollProgressBar from '@/components/ui/ScrollProgressBar'
import BackToTop from '@/components/ui/BackToTop'
import CustomCursor from '@/components/ui/CustomCursor'
import CommandPalette from '@/components/ui/CommandPalette'
import ParticleField from '@/components/ui/ParticleField'
import HeroSection from '@/components/sections/HeroSection'
import AboutSection from '@/components/sections/AboutSection'
import SkillsSection from '@/components/sections/SkillsSection'
import ProjectsSection from '@/components/sections/ProjectsSection'
import ProfessionalPresenceSection from '@/components/sections/ProfessionalPresenceSection'
import EducationSection from '@/components/sections/EducationSection'
import ContactSection from '@/components/sections/ContactSection'

export default function App() {
  const [loaded, setLoaded] = useState(false)
  const [cmdOpen, setCmdOpen] = useState(false)

  useSmoothScroll()

  useEffect(() => {
    const handleKey = (e: KeyboardEvent) => {
      if ((e.ctrlKey || e.metaKey) && e.key === 'k') {
        e.preventDefault()
        setCmdOpen(v => !v)
      }
    }
    window.addEventListener('keydown', handleKey)
    return () => window.removeEventListener('keydown', handleKey)
  }, [])

  if (!loaded) {
    return <LoadingScreen onComplete={() => setLoaded(true)} />
  }

  return (
    <div className="relative min-h-screen bg-[#080B14]">
      {/* Global effects */}
      <CustomCursor />
      <ScrollProgressBar />
      <ParticleField />

      {/* Command palette */}
      <CommandPalette open={cmdOpen} onClose={() => setCmdOpen(false)} />

      {/* Command palette hint */}
      <div className="fixed bottom-8 left-6 z-40 hidden md:flex items-center gap-2 text-xs text-[#475569] font-mono glass rounded-lg px-3 py-2 border border-white/5">
        <span className="px-1.5 py-0.5 bg-white/5 rounded text-[10px]">⌘K</span>
        <span>Command palette</span>
      </div>

      {/* Navigation */}
      <Navbar />

      {/* Sections */}
      <main id="main-content">
        <HeroSection />
        <AboutSection />
        <SkillsSection />
        <ProjectsSection />
        <ProfessionalPresenceSection />
        <EducationSection />
        <ContactSection />
      </main>

      <Footer />
      <BackToTop />
    </div>
  )
}
