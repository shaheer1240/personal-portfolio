import { useEffect, useState, useCallback } from 'react'
import { motion, AnimatePresence } from 'framer-motion'
import { Search, Hash, Mail, User, Code2, GraduationCap, X } from 'lucide-react'
import { scrollToSection } from '@/hooks/useSmoothScroll'

const commands = [
  { id: 'hero', label: 'Go Home', description: 'Back to the top', icon: Hash, section: 'hero' },
  { id: 'about', label: 'About Me', description: 'Learn who I am', icon: User, section: 'about' },
  { id: 'skills', label: 'Skills', description: 'View my technical skills', icon: Code2, section: 'skills' },
  { id: 'projects', label: 'Projects', description: 'See my featured work', icon: Code2, section: 'projects' },
  { id: 'presence', label: 'Professional Presence', description: 'LinkedIn, GitHub & more', icon: User, section: 'presence' },
  { id: 'education', label: 'Education', description: 'Credentials & certifications', icon: GraduationCap, section: 'education' },
  { id: 'contact', label: 'Contact', description: 'Get in touch', icon: Mail, section: 'contact' },
]

interface Props {
  open: boolean
  onClose: () => void
}

export default function CommandPalette({ open, onClose }: Props) {
  const [query, setQuery] = useState('')
  const [selected, setSelected] = useState(0)

  const filtered = commands.filter(
    c =>
      c.label.toLowerCase().includes(query.toLowerCase()) ||
      c.description.toLowerCase().includes(query.toLowerCase())
  )

  const execute = useCallback((section: string) => {
    scrollToSection(section)
    onClose()
    setQuery('')
  }, [onClose])

  useEffect(() => {
    if (!open) { setQuery(''); setSelected(0) }
  }, [open])

  useEffect(() => {
    const handleKey = (e: KeyboardEvent) => {
      if (!open) return
      if (e.key === 'ArrowDown') { e.preventDefault(); setSelected(s => Math.min(s + 1, filtered.length - 1)) }
      if (e.key === 'ArrowUp') { e.preventDefault(); setSelected(s => Math.max(s - 1, 0)) }
      if (e.key === 'Enter' && filtered[selected]) execute(filtered[selected].section)
      if (e.key === 'Escape') onClose()
    }
    window.addEventListener('keydown', handleKey)
    return () => window.removeEventListener('keydown', handleKey)
  }, [open, filtered, selected, execute, onClose])

  return (
    <AnimatePresence>
      {open && (
        <>
          <motion.div
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            onClick={onClose}
            className="fixed inset-0 bg-black/60 backdrop-blur-sm z-[9990]"
            aria-hidden="true"
          />
          <motion.div
            initial={{ opacity: 0, scale: 0.95, y: -20 }}
            animate={{ opacity: 1, scale: 1, y: 0 }}
            exit={{ opacity: 0, scale: 0.95, y: -20 }}
            transition={{ duration: 0.2, ease: [0.22, 1, 0.36, 1] }}
            className="fixed top-1/4 left-1/2 -translate-x-1/2 w-full max-w-md z-[9991] glass-strong rounded-2xl border border-white/10 shadow-2xl overflow-hidden"
            role="dialog"
            aria-label="Command palette"
          >
            {/* Search input */}
            <div className="flex items-center gap-3 px-4 py-3 border-b border-white/5">
              <Search size={16} className="text-[#475569] flex-shrink-0" />
              <input
                autoFocus
                type="text"
                placeholder="Search sections..."
                value={query}
                onChange={e => { setQuery(e.target.value); setSelected(0) }}
                className="flex-1 bg-transparent text-sm text-white placeholder-[#475569] outline-none"
                aria-label="Command search"
              />
              <button onClick={onClose} className="text-[#475569] hover:text-white transition-colors">
                <X size={16} />
              </button>
            </div>

            {/* Results */}
            <div className="py-2 max-h-72 overflow-y-auto" role="listbox">
              {filtered.length === 0 ? (
                <div className="px-4 py-8 text-center text-sm text-[#475569]">No results found</div>
              ) : (
                filtered.map((cmd, i) => (
                  <button
                    key={cmd.id}
                    role="option"
                    aria-selected={i === selected}
                    onClick={() => execute(cmd.section)}
                    onMouseEnter={() => setSelected(i)}
                    className={`w-full flex items-center gap-3 px-4 py-3 text-left transition-all ${
                      i === selected ? 'bg-[#00D4FF]/10 text-white' : 'text-[#94A3B8] hover:bg-white/5'
                    }`}
                  >
                    <cmd.icon size={16} className={i === selected ? 'text-[#00D4FF]' : 'text-[#475569]'} />
                    <div>
                      <div className="text-sm font-medium">{cmd.label}</div>
                      <div className="text-xs text-[#475569]">{cmd.description}</div>
                    </div>
                    {i === selected && (
                      <div className="ml-auto text-xs font-mono text-[#475569] bg-white/5 px-2 py-0.5 rounded">
                        ↵
                      </div>
                    )}
                  </button>
                ))
              )}
            </div>

            <div className="px-4 py-2 border-t border-white/5 flex items-center gap-4 text-xs text-[#475569]">
              <span>↑↓ navigate</span>
              <span>↵ select</span>
              <span>esc close</span>
            </div>
          </motion.div>
        </>
      )}
    </AnimatePresence>
  )
}
