import { useEffect, useRef } from 'react'
import { motion, useMotionValue, useSpring } from 'framer-motion'

export default function CustomCursor() {
  const cursorX = useMotionValue(-100)
  const cursorY = useMotionValue(-100)
  const trailX = useMotionValue(-100)
  const trailY = useMotionValue(-100)
  const isHovering = useRef(false)
  const dotRef = useRef<HTMLDivElement>(null)

  const springX = useSpring(trailX, { stiffness: 150, damping: 20 })
  const springY = useSpring(trailY, { stiffness: 150, damping: 20 })

  useEffect(() => {
    const prefersReduced = window.matchMedia('(prefers-reduced-motion: reduce)').matches
    if (prefersReduced) return

    const move = (e: MouseEvent) => {
      cursorX.set(e.clientX)
      cursorY.set(e.clientY)
      trailX.set(e.clientX)
      trailY.set(e.clientY)
    }

    const onEnter = () => {
      isHovering.current = true
      dotRef.current?.classList.add('scale-150', 'opacity-50')
    }
    const onLeave = () => {
      isHovering.current = false
      dotRef.current?.classList.remove('scale-150', 'opacity-50')
    }

    window.addEventListener('mousemove', move)

    const interactables = document.querySelectorAll('a, button, [role="button"], input, textarea')
    interactables.forEach(el => {
      el.addEventListener('mouseenter', onEnter)
      el.addEventListener('mouseleave', onLeave)
    })

    return () => {
      window.removeEventListener('mousemove', move)
    }
  }, [cursorX, cursorY, trailX, trailY])

  return (
    <>
      {/* Dot cursor */}
      <motion.div
        ref={dotRef}
        className="fixed top-0 left-0 w-2 h-2 rounded-full bg-[#00D4FF] pointer-events-none z-[9999] transition-transform duration-150"
        style={{
          x: cursorX,
          y: cursorY,
          translateX: '-50%',
          translateY: '-50%',
        }}
      />
      {/* Ring cursor */}
      <motion.div
        className="fixed top-0 left-0 w-8 h-8 rounded-full border border-[#00D4FF]/40 pointer-events-none z-[9998]"
        style={{
          x: springX,
          y: springY,
          translateX: '-50%',
          translateY: '-50%',
        }}
      />
    </>
  )
}
