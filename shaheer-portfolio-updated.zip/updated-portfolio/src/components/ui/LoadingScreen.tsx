import { motion, AnimatePresence } from 'framer-motion'
import { useEffect, useState } from 'react'

interface Props {
  onComplete: () => void
}

export default function LoadingScreen({ onComplete }: Props) {
  const [progress, setProgress] = useState(0)
  const [visible, setVisible] = useState(true)

  useEffect(() => {
    const duration = 1800
    const interval = 30
    const steps = duration / interval
    let step = 0

    const timer = setInterval(() => {
      step++
      const eased = Math.min(100, Math.round((1 - Math.pow(1 - step / steps, 3)) * 100))
      setProgress(eased)

      if (step >= steps) {
        clearInterval(timer)
        setTimeout(() => {
          setVisible(false)
          setTimeout(onComplete, 600)
        }, 200)
      }
    }, interval)

    return () => clearInterval(timer)
  }, [onComplete])

  return (
    <AnimatePresence>
      {visible && (
        <motion.div
          initial={{ opacity: 1 }}
          exit={{ opacity: 0, scale: 0.98 }}
          transition={{ duration: 0.6, ease: 'easeInOut' }}
          className="fixed inset-0 bg-[#080B14] z-[99999] flex flex-col items-center justify-center"
        >
          {/* Logo / Name */}
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.5 }}
            className="mb-12 text-center"
          >
            <div className="font-mono text-xs text-[#94A3B8] tracking-[0.3em] uppercase mb-3">
              Loading Portfolio
            </div>
            <div className="text-4xl font-bold tracking-tight">
              <span className="gradient-text">Shaheer</span>
            </div>
          </motion.div>

          {/* Progress bar */}
          <div className="w-48 h-px bg-white/10 relative overflow-hidden">
            <motion.div
              className="absolute inset-y-0 left-0 bg-gradient-to-r from-[#00D4FF] to-[#8B5CF6]"
              style={{ width: `${progress}%` }}
              transition={{ duration: 0 }}
            />
          </div>

          <motion.div
            className="font-mono text-xs text-[#475569] mt-4 tabular-nums"
            animate={{ opacity: [0.5, 1] }}
            transition={{ duration: 0.5, repeat: Infinity, repeatType: 'reverse' }}
          >
            {progress}%
          </motion.div>
        </motion.div>
      )}
    </AnimatePresence>
  )
}
