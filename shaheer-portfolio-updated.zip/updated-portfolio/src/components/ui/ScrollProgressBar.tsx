import { motion, useScroll, useSpring } from 'framer-motion'

export default function ScrollProgressBar() {
  const { scrollYProgress } = useScroll()
  const scaleX = useSpring(scrollYProgress, { stiffness: 100, damping: 30, restDelta: 0.001 })

  return (
    <motion.div
      className="fixed top-0 left-0 right-0 h-0.5 bg-gradient-to-r from-[#00D4FF] via-[#3B82F6] to-[#8B5CF6] origin-left z-[9999]"
      style={{ scaleX }}
      aria-hidden="true"
    />
  )
}
