import RevealSection from './RevealSection'

interface Props {
  eyebrow?: string
  title: string
  subtitle?: string
  centered?: boolean
}

export default function SectionHeader({ eyebrow, title, subtitle, centered = false }: Props) {
  return (
    <div className={`mb-16 ${centered ? 'text-center' : ''}`}>
      <RevealSection>
        {eyebrow && (
          <div className="inline-flex items-center gap-2 mb-4">
            <div className="h-px w-6 bg-[#00D4FF]" />
            <span className="font-mono text-xs tracking-[0.25em] text-[#00D4FF] uppercase">{eyebrow}</span>
            <div className="h-px w-6 bg-[#00D4FF]" />
          </div>
        )}
        <h2 className="text-3xl md:text-4xl lg:text-5xl font-bold tracking-tight text-white">
          {title}
        </h2>
        {subtitle && (
          <p className="mt-4 text-[#94A3B8] text-lg max-w-2xl leading-relaxed" style={{ marginLeft: centered ? 'auto' : undefined, marginRight: centered ? 'auto' : undefined }}>
            {subtitle}
          </p>
        )}
      </RevealSection>
    </div>
  )
}
