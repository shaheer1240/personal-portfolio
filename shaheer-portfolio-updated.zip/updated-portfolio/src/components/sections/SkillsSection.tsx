import { motion } from 'framer-motion'
import SectionHeader from '@/components/ui/SectionHeader'
import RevealSection from '@/components/ui/RevealSection'
import { skills } from '@/data/cv'

const categories = [
  {
    label: 'Frontend Development',
    color: '#00D4FF',
    items: skills.frontend,
    emoji: '🎨',
  },
  {
    label: 'Backend Development',
    color: '#8B5CF6',
    items: skills.backend,
    emoji: '⚙️',
  },
  {
    label: 'Database',
    color: '#3B82F6',
    items: skills.database,
    emoji: '🗄️',
  },
  {
    label: 'Tools & Design',
    color: '#10B981',
    items: skills.tools,
    emoji: '🛠️',
  },
]

function SkillBar({ name, level, color, delay }: { name: string; level: number; color: string; delay: number }) {
  return (
    <RevealSection delay={delay}>
      <div className="space-y-2">
        <div className="flex items-center justify-between">
          <span className="text-sm font-medium text-[#94A3B8]">{name}</span>
          <span className="font-mono text-xs" style={{ color }}>{level}%</span>
        </div>
        <div className="h-1 bg-white/5 rounded-full overflow-hidden">
          <motion.div
            className="h-full rounded-full"
            style={{ background: `linear-gradient(90deg, ${color}80, ${color})` }}
            initial={{ width: 0 }}
            whileInView={{ width: `${level}%` }}
            viewport={{ once: true }}
            transition={{ duration: 1, delay: delay + 0.2, ease: [0.22, 1, 0.36, 1] }}
          />
        </div>
      </div>
    </RevealSection>
  )
}

const allTechBadges = [
  'HTML5', 'CSS3', 'Bootstrap 5', 'JavaScript', 'React.js', 'Tailwind CSS',
  'PHP', 'ASP.NET MVC', 'C#', 'Flutter', 'Dart',
  'MySQL', 'SQL Server', 'Firebase', 'MongoDB',
  'Figma', 'Git', 'GitHub', 'VS Code', 'REST APIs', 'Agile', 'SDLC',
]

export default function SkillsSection() {
  return (
    <section id="skills" className="section-padding relative" aria-label="Skills">
      <div className="max-w-5xl mx-auto px-6">
        <SectionHeader
          eyebrow="Technical Skills"
          title="Tools of the trade"
          subtitle="A curated stack built through real project experience — not just tutorials."
        />

        {/* Category cards */}
        <div className="grid md:grid-cols-2 gap-6 mb-10">
          {categories.map((cat, catIdx) => (
            <RevealSection key={cat.label} delay={catIdx * 0.1}>
              <div
                className="glass rounded-2xl p-6 border border-white/5 hover:border-white/10 transition-all duration-300 h-full"
                style={{ borderTopColor: `${cat.color}20` }}
              >
                <div className="flex items-center gap-3 mb-6">
                  <div
                    className="w-10 h-10 rounded-xl flex items-center justify-center text-xl"
                    style={{ background: `${cat.color}15` }}
                  >
                    {cat.emoji}
                  </div>
                  <h3 className="font-semibold text-white">{cat.label}</h3>
                  <div
                    className="ml-auto h-px flex-1 max-w-16 opacity-30"
                    style={{ background: cat.color }}
                  />
                </div>
                <div className="space-y-4">
                  {cat.items.map((skill, skillIdx) => (
                    <SkillBar
                      key={skill.name}
                      name={skill.name}
                      level={skill.level}
                      color={cat.color}
                      delay={catIdx * 0.1 + skillIdx * 0.05}
                    />
                  ))}
                </div>
              </div>
            </RevealSection>
          ))}
        </div>

        {/* Currently Learning */}
        <RevealSection>
          <div className="glass rounded-2xl p-6 border border-[#F59E0B]/20 mb-6">
            <div className="flex items-center gap-3 mb-4">
              <span className="text-xl">🚀</span>
              <p className="text-sm font-semibold text-[#F59E0B]">Currently Learning</p>
              <span className="ml-auto text-xs font-mono text-[#475569]">Active Growth</span>
            </div>
            <div className="flex flex-wrap gap-2">
              {skills.learning.map(tech => (
                <span
                  key={tech}
                  className="px-3 py-1.5 text-xs font-medium rounded-lg border text-[#F59E0B] border-[#F59E0B]/30 bg-[#F59E0B]/10"
                >
                  {tech}
                </span>
              ))}
            </div>
          </div>
        </RevealSection>

        {/* All tech badges */}
        <RevealSection>
          <div className="glass rounded-2xl p-6 border border-white/5">
            <p className="text-xs font-mono text-[#475569] tracking-widest uppercase mb-4">All Technologies</p>
            <div className="flex flex-wrap gap-2">
              {allTechBadges.map((tech, i) => (
                <motion.span
                  key={tech}
                  initial={{ opacity: 0, scale: 0.8 }}
                  whileInView={{ opacity: 1, scale: 1 }}
                  viewport={{ once: true }}
                  transition={{ delay: i * 0.03, duration: 0.3 }}
                  whileHover={{ scale: 1.05, borderColor: 'rgba(0,212,255,0.4)' }}
                  className="px-3 py-1.5 text-xs font-medium bg-white/5 text-[#94A3B8] border border-white/5 rounded-lg transition-colors"
                >
                  {tech}
                </motion.span>
              ))}
            </div>
          </div>
        </RevealSection>
      </div>
    </section>
  )
}
