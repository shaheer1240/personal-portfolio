import { useEffect, useRef } from 'react'
import { motion } from 'framer-motion'
import { ArrowDown, Mail, ExternalLink, Github, Linkedin } from 'lucide-react'
import { scrollToSection } from '@/hooks/useSmoothScroll'
import { personal } from '@/data/cv'

const roles = ['.NET MVC Developer', 'Flutter Developer', 'PHP Developer', 'Full-Stack Builder', 'Problem Solver']

function TypewriterText() {
  const containerRef = useRef<HTMLSpanElement>(null)

  useEffect(() => {
    const el = containerRef.current
    if (!el) return
    let roleIdx = 0
    let charIdx = 0
    let deleting = false
    let timeout: ReturnType<typeof setTimeout>

    const tick = () => {
      const current = roles[roleIdx]
      if (!deleting) {
        el.textContent = current.slice(0, charIdx + 1)
        charIdx++
        if (charIdx === current.length) {
          deleting = true
          timeout = setTimeout(tick, 2000)
          return
        }
      } else {
        el.textContent = current.slice(0, charIdx - 1)
        charIdx--
        if (charIdx === 0) {
          deleting = false
          roleIdx = (roleIdx + 1) % roles.length
        }
      }
      timeout = setTimeout(tick, deleting ? 50 : 100)
    }

    timeout = setTimeout(tick, 800)
    return () => clearTimeout(timeout)
  }, [])

  return <span ref={containerRef} className="gradient-text" />
}

const container = {
  hidden: {},
  visible: { transition: { staggerChildren: 0.12, delayChildren: 0.3 } },
}
const item = {
  hidden: { opacity: 0, y: 20 },
  visible: { opacity: 1, y: 0, transition: { duration: 0.7, ease: [0.22, 1, 0.36, 1] } },
}

export default function HeroSection() {
  return (
    <section
      id="hero"
      className="relative min-h-screen flex items-center justify-center overflow-hidden"
      aria-label="Introduction"
    >
      {/* Background spotlight */}
      <div className="absolute inset-0 pointer-events-none">
        <div className="absolute top-1/4 left-1/2 -translate-x-1/2 -translate-y-1/2 w-[600px] h-[600px] rounded-full bg-[#00D4FF]/5 blur-[120px]" />
        <div className="absolute top-1/3 left-1/4 w-[400px] h-[400px] rounded-full bg-[#8B5CF6]/5 blur-[100px]" />
        <div className="absolute bottom-1/4 right-1/4 w-[300px] h-[300px] rounded-full bg-[#3B82F6]/5 blur-[80px]" />
      </div>

      {/* Grid lines overlay */}
      <div
        className="absolute inset-0 pointer-events-none opacity-[0.03]"
        style={{
          backgroundImage: `
            linear-gradient(rgba(0,212,255,1) 1px, transparent 1px),
            linear-gradient(90deg, rgba(0,212,255,1) 1px, transparent 1px)
          `,
          backgroundSize: '80px 80px',
        }}
      />

      <div className="relative z-10 max-w-5xl mx-auto px-6 text-center">
        <motion.div variants={container} initial="hidden" animate="visible">
          {/* Eyebrow */}
          <motion.div variants={item} className="flex items-center justify-center gap-3 mb-6">
            <div className="h-px w-10 bg-gradient-to-r from-transparent to-[#00D4FF]" />
            <span className="font-mono text-xs tracking-[0.3em] text-[#00D4FF] uppercase">
              Available for opportunities
            </span>
            <div className="h-px w-10 bg-gradient-to-l from-transparent to-[#00D4FF]" />
          </motion.div>

          {/* Main heading */}
          <motion.h1
            variants={item}
            className="text-5xl md:text-7xl lg:text-8xl font-bold tracking-tight leading-[0.95] mb-6"
          >
            <span className="text-white">Hi, I'm </span>
            <span className="gradient-text text-glow">{personal.name}</span>
          </motion.h1>

          {/* Dynamic role */}
          <motion.div
            variants={item}
            className="text-2xl md:text-3xl font-medium text-[#94A3B8] mb-6 h-10 flex items-center justify-center"
          >
            <span className="mr-2">I'm a</span>
            <TypewriterText />
            <span className="ml-0.5 w-0.5 h-7 bg-[#00D4FF] inline-block animate-pulse" />
          </motion.div>

          {/* Bio */}
          <motion.p
            variants={item}
            className="max-w-xl mx-auto text-[#94A3B8] text-lg leading-relaxed mb-10"
          >
            Based in <span className="text-white">Karachi, Pakistan</span> — an O-Level student building
            real-world applications with ASP.NET MVC, PHP, Flutter, and Firebase. Passionate about clean
            code and user-focused design.
          </motion.p>

          {/* CTAs */}
          <motion.div variants={item} className="flex flex-wrap items-center justify-center gap-4 mb-12">
            <button
              onClick={() => scrollToSection('projects')}
              className="group relative px-7 py-3.5 bg-[#00D4FF] text-[#080B14] font-semibold rounded-xl overflow-hidden transition-all duration-300 hover:shadow-glow-md hover:scale-105"
            >
              <span className="relative z-10 flex items-center gap-2">
                View My Work
                <ExternalLink size={16} className="group-hover:translate-x-1 transition-transform" />
              </span>
            </button>
            <button
              onClick={() => scrollToSection('contact')}
              className="px-7 py-3.5 glass-strong font-semibold rounded-xl transition-all duration-300 hover:border-[#00D4FF]/30 hover:bg-white/5 border border-white/10 flex items-center gap-2 text-white"
            >
              <Mail size={16} />
              Get In Touch
            </button>
          </motion.div>

          {/* Social links */}
          <motion.div variants={item} className="flex flex-wrap items-center justify-center gap-5">
            <a
              href={`mailto:${personal.email}`}
              aria-label="Email Shaheer"
              className="group flex items-center gap-2 text-[#475569] hover:text-[#00D4FF] transition-colors text-sm font-mono"
            >
              <Mail size={14} />
              <span className="group-hover:underline">{personal.email}</span>
            </a>
            <div className="w-px h-4 bg-white/10" />
            <a
              href={personal.github}
              target="_blank"
              rel="noopener noreferrer"
              aria-label="GitHub profile"
              className="flex items-center gap-2 text-[#475569] hover:text-[#00D4FF] transition-colors text-sm"
            >
              <Github size={14} />
              GitHub
            </a>
            <div className="w-px h-4 bg-white/10" />
            <a
              href={personal.linkedin}
              target="_blank"
              rel="noopener noreferrer"
              aria-label="LinkedIn profile"
              className="flex items-center gap-2 text-[#475569] hover:text-[#00D4FF] transition-colors text-sm"
            >
              <Linkedin size={14} />
              LinkedIn
            </a>
          </motion.div>
        </motion.div>
      </div>

      {/* Scroll indicator */}
      <motion.button
        initial={{ opacity: 0 }}
        animate={{ opacity: 1 }}
        transition={{ delay: 2, duration: 0.8 }}
        onClick={() => scrollToSection('about')}
        className="absolute bottom-10 left-1/2 -translate-x-1/2 flex flex-col items-center gap-2 text-[#475569] hover:text-[#00D4FF] transition-colors"
        aria-label="Scroll to about section"
      >
        <span className="text-xs font-mono tracking-widest uppercase">Scroll</span>
        <motion.div
          animate={{ y: [0, 6, 0] }}
          transition={{ duration: 1.5, repeat: Infinity, ease: 'easeInOut' }}
        >
          <ArrowDown size={16} />
        </motion.div>
      </motion.button>
    </section>
  )
}
