import { useState, useRef } from 'react'
import { motion } from 'framer-motion'
import emailjs from '@emailjs/browser'
import { Mail, MapPin, Send, CheckCircle, AlertCircle, Loader2 } from 'lucide-react'
import SectionHeader from '@/components/ui/SectionHeader'
import RevealSection from '@/components/ui/RevealSection'
import { personal } from '@/data/cv'

type Status = 'idle' | 'loading' | 'success' | 'error'

interface FormState {
  name: string
  email: string
  subject: string
  message: string
}

const EMAILJS_SERVICE_ID = import.meta.env.VITE_EMAILJS_SERVICE_ID || 'YOUR_SERVICE_ID'
const EMAILJS_TEMPLATE_ID = import.meta.env.VITE_EMAILJS_TEMPLATE_ID || 'YOUR_TEMPLATE_ID'
const EMAILJS_PUBLIC_KEY = import.meta.env.VITE_EMAILJS_PUBLIC_KEY || 'YOUR_PUBLIC_KEY'

function InputField({
  label,
  name,
  type = 'text',
  placeholder,
  value,
  onChange,
  required,
}: {
  label: string
  name: string
  type?: string
  placeholder: string
  value: string
  onChange: (e: React.ChangeEvent<HTMLInputElement | HTMLTextAreaElement>) => void
  required?: boolean
}) {
  return (
    <div className="space-y-2">
      <label htmlFor={name} className="block text-xs font-medium text-[#94A3B8] tracking-wide uppercase">
        {label} {required && <span className="text-[#00D4FF]">*</span>}
      </label>
      {type === 'textarea' ? (
        <textarea
          id={name}
          name={name}
          placeholder={placeholder}
          value={value}
          onChange={onChange}
          required={required}
          rows={5}
          className="w-full px-4 py-3 bg-white/5 border border-white/8 rounded-xl text-white text-sm placeholder-[#475569] focus:outline-none focus:border-[#00D4FF]/50 focus:bg-white/8 transition-all duration-200 resize-none"
        />
      ) : (
        <input
          id={name}
          name={name}
          type={type}
          placeholder={placeholder}
          value={value}
          onChange={onChange}
          required={required}
          className="w-full px-4 py-3 bg-white/5 border border-white/8 rounded-xl text-white text-sm placeholder-[#475569] focus:outline-none focus:border-[#00D4FF]/50 focus:bg-white/8 transition-all duration-200"
        />
      )}
    </div>
  )
}

export default function ContactSection() {
  const formRef = useRef<HTMLFormElement>(null)
  const [form, setForm] = useState<FormState>({ name: '', email: '', subject: '', message: '' })
  const [status, setStatus] = useState<Status>('idle')
  const [copied, setCopied] = useState(false)

  const handleChange = (e: React.ChangeEvent<HTMLInputElement | HTMLTextAreaElement>) => {
    setForm(prev => ({ ...prev, [e.target.name]: e.target.value }))
  }

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault()
    setStatus('loading')

    try {
      await emailjs.send(
        EMAILJS_SERVICE_ID,
        EMAILJS_TEMPLATE_ID,
        {
          from_name: form.name,
          from_email: form.email,
          subject: form.subject,
          message: form.message,
          to_name: 'Shaheer',
        },
        EMAILJS_PUBLIC_KEY
      )
      setStatus('success')
      setForm({ name: '', email: '', subject: '', message: '' })
    } catch {
      setStatus('error')
    }
  }

  const copyEmail = () => {
    navigator.clipboard.writeText(personal.email).then(() => {
      setCopied(true)
      setTimeout(() => setCopied(false), 2000)
    })
  }

  return (
    <section id="contact" className="section-padding relative" aria-label="Contact">
      {/* Background glow */}
      <div className="absolute inset-0 pointer-events-none">
        <div className="absolute bottom-0 left-1/2 -translate-x-1/2 w-[800px] h-[400px] rounded-full bg-[#00D4FF]/3 blur-[120px]" />
      </div>

      <div className="max-w-5xl mx-auto px-6 relative z-10">
        <SectionHeader
          eyebrow="Get In Touch"
          title="Let's build something together"
          subtitle="I'm actively looking for new opportunities. Whether you have a project, a role, or just want to connect — my inbox is open."
          centered
        />

        <div className="grid lg:grid-cols-5 gap-10 items-start">
          {/* Contact info */}
          <div className="lg:col-span-2 space-y-4">
            <RevealSection direction="left">
              <div
                className="glass rounded-2xl p-5 border border-white/5 flex items-center gap-4 group hover:border-[#00D4FF]/20 transition-all duration-300 cursor-pointer"
                onClick={copyEmail}
                role="button"
                tabIndex={0}
                aria-label="Copy email address"
                onKeyDown={e => e.key === 'Enter' && copyEmail()}
              >
                <div className="w-10 h-10 rounded-xl bg-[#00D4FF]/10 flex items-center justify-center flex-shrink-0">
                  <Mail size={18} className="text-[#00D4FF]" />
                </div>
                <div className="flex-1 min-w-0">
                  <p className="text-xs text-[#475569] mb-0.5">Email</p>
                  <p className="text-sm text-white font-medium truncate">{personal.email}</p>
                </div>
                <span className="text-xs text-[#475569] flex-shrink-0">
                  {copied ? '✓ Copied!' : 'Click to copy'}
                </span>
              </div>
            </RevealSection>

            <RevealSection direction="left" delay={0.1}>
              <div className="glass rounded-2xl p-5 border border-white/5 flex items-center gap-4">
                <div className="w-10 h-10 rounded-xl bg-[#8B5CF6]/10 flex items-center justify-center flex-shrink-0">
                  <MapPin size={18} className="text-[#8B5CF6]" />
                </div>
                <div>
                  <p className="text-xs text-[#475569] mb-0.5">Location</p>
                  <p className="text-sm text-white font-medium">{personal.location}</p>
                </div>
              </div>
            </RevealSection>

            <RevealSection direction="left" delay={0.2}>
              <div className="glass rounded-2xl p-5 border border-white/5">
                <p className="text-xs font-mono text-[#475569] tracking-widest uppercase mb-3">Languages</p>
                <div className="flex flex-col gap-2">
                  {personal.languages.map(lang => (
                    <div key={lang.name} className="flex items-center justify-between">
                      <span className="text-sm text-white">{lang.name}</span>
                      <span className="text-xs px-2 py-0.5 bg-white/5 rounded text-[#94A3B8]">{lang.level}</span>
                    </div>
                  ))}
                </div>
              </div>
            </RevealSection>

            <RevealSection direction="left" delay={0.3}>
              <div className="glass rounded-2xl p-5 border border-[#00D4FF]/10">
                <p className="text-xs text-[#00D4FF] font-mono tracking-wider mb-2">✓ OPEN TO WORK</p>
                <p className="text-xs text-[#94A3B8] leading-relaxed">
                  Currently available for full-time positions, contract work, and freelance projects.
                </p>
              </div>
            </RevealSection>
          </div>

          {/* Contact form */}
          <div className="lg:col-span-3">
            <RevealSection direction="right">
              <div className="glass rounded-2xl p-6 md:p-8 border border-white/5">
                {status === 'success' ? (
                  <motion.div
                    initial={{ opacity: 0, scale: 0.9 }}
                    animate={{ opacity: 1, scale: 1 }}
                    className="flex flex-col items-center justify-center py-12 text-center"
                  >
                    <CheckCircle className="text-[#00D4FF] mb-4" size={40} />
                    <h3 className="text-xl font-bold text-white mb-2">Message sent!</h3>
                    <p className="text-[#94A3B8] mb-6">Thanks for reaching out. I'll get back to you soon.</p>
                    <button
                      onClick={() => setStatus('idle')}
                      className="text-sm text-[#00D4FF] hover:underline"
                    >
                      Send another message
                    </button>
                  </motion.div>
                ) : (
                  <form ref={formRef} onSubmit={handleSubmit} className="space-y-5" noValidate>
                    <div className="grid sm:grid-cols-2 gap-5">
                      <InputField
                        label="Your Name"
                        name="name"
                        placeholder="John Doe"
                        value={form.name}
                        onChange={handleChange}
                        required
                      />
                      <InputField
                        label="Email Address"
                        name="email"
                        type="email"
                        placeholder="john@example.com"
                        value={form.email}
                        onChange={handleChange}
                        required
                      />
                    </div>
                    <InputField
                      label="Subject"
                      name="subject"
                      placeholder="Let's discuss a project..."
                      value={form.subject}
                      onChange={handleChange}
                      required
                    />
                    <InputField
                      label="Message"
                      name="message"
                      type="textarea"
                      placeholder="Tell me about your project or opportunity..."
                      value={form.message}
                      onChange={handleChange}
                      required
                    />

                    {status === 'error' && (
                      <div className="flex items-center gap-2 p-3 bg-red-500/10 border border-red-500/20 rounded-lg text-sm text-red-400">
                        <AlertCircle size={16} />
                        Failed to send. Please try emailing directly.
                      </div>
                    )}

                    <button
                      type="submit"
                      disabled={status === 'loading'}
                      className="w-full py-3.5 bg-[#00D4FF] text-[#080B14] font-semibold rounded-xl flex items-center justify-center gap-2 hover:bg-[#00D4FF]/90 transition-all duration-200 disabled:opacity-60 disabled:cursor-not-allowed hover:shadow-glow-sm"
                    >
                      {status === 'loading' ? (
                        <><Loader2 size={18} className="animate-spin" /> Sending...</>
                      ) : (
                        <><Send size={18} /> Send Message</>
                      )}
                    </button>
                  </form>
                )}
              </div>
            </RevealSection>
          </div>
        </div>
      </div>
    </section>
  )
}
