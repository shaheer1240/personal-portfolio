import { GraduationCap, Award, CheckCircle2, Briefcase } from 'lucide-react'
import SectionHeader from '@/components/ui/SectionHeader'
import RevealSection from '@/components/ui/RevealSection'
import { education, certifications, experience } from '@/data/cv'

export default function EducationSection() {
  return (
    <section id="education" className="section-padding relative" aria-label="Education and certifications">
      <div className="max-w-5xl mx-auto px-6">
        <SectionHeader
          eyebrow="Credentials"
          title="Education & Certifications"
        />

        {/* Experience */}
        <RevealSection>
          <div className="mb-12">
            <div className="flex items-center gap-3 mb-6">
              <div className="w-8 h-8 rounded-lg bg-[#F59E0B]/10 flex items-center justify-center">
                <Briefcase size={16} className="text-[#F59E0B]" />
              </div>
              <h3 className="font-semibold text-white">Professional Experience</h3>
            </div>
            <div className="space-y-4">
              {experience.map((exp, i) => (
                <RevealSection key={exp.company} direction="left" delay={i * 0.1}>
                  <div className="glass rounded-2xl p-6 border border-white/5 hover:border-[#F59E0B]/20 transition-all duration-300 relative overflow-hidden">
                    <div className="absolute top-0 left-0 w-1 h-full bg-gradient-to-b from-[#F59E0B] to-transparent rounded-l-2xl opacity-60" />
                    <div className="pl-2">
                      <div className="flex items-start justify-between gap-4 mb-3">
                        <div>
                          <h4 className="font-bold text-white">{exp.role}</h4>
                          <p className="text-sm text-[#F59E0B] font-medium">{exp.company}</p>
                        </div>
                        <span className="text-xs font-mono text-[#475569] flex-shrink-0">{exp.period}</span>
                      </div>
                      <ul className="space-y-1.5">
                        {exp.bullets.map(b => (
                          <li key={b} className="flex items-start gap-2 text-sm text-[#94A3B8]">
                            <div className="w-1 h-1 rounded-full bg-[#F59E0B]/60 mt-2 flex-shrink-0" />
                            {b}
                          </li>
                        ))}
                      </ul>
                    </div>
                  </div>
                </RevealSection>
              ))}
            </div>
          </div>
        </RevealSection>

        <div className="grid lg:grid-cols-2 gap-10">
          {/* Education */}
          <div>
            <RevealSection direction="left">
              <div className="flex items-center gap-3 mb-6">
                <div className="w-8 h-8 rounded-lg bg-[#00D4FF]/10 flex items-center justify-center">
                  <GraduationCap size={16} className="text-[#00D4FF]" />
                </div>
                <h3 className="font-semibold text-white">Education</h3>
              </div>
            </RevealSection>

            <div className="space-y-4">
              {education.map((edu, i) => (
                <RevealSection key={edu.degree} direction="left" delay={i * 0.1 + 0.1}>
                  <div className="glass rounded-2xl p-6 border border-white/5 hover:border-[#00D4FF]/20 transition-all duration-300 group relative overflow-hidden">
                    <div className="absolute top-0 left-0 w-1 h-full bg-gradient-to-b from-[#00D4FF] to-transparent rounded-l-2xl opacity-60" />
                    <div className="pl-2">
                      <div className="text-xs font-mono text-[#00D4FF] mb-2 tracking-wider">{edu.location}</div>
                      <h4 className="font-bold text-white mb-1 leading-tight">{edu.degree}</h4>
                      <p className="text-sm text-[#475569] font-medium mb-3">{edu.institution}</p>
                      <p className="text-sm text-[#94A3B8] leading-relaxed">{edu.description}</p>
                    </div>
                  </div>
                </RevealSection>
              ))}
            </div>
          </div>

          {/* Certifications */}
          <div>
            <RevealSection direction="right">
              <div className="flex items-center gap-3 mb-6">
                <div className="w-8 h-8 rounded-lg bg-[#8B5CF6]/10 flex items-center justify-center">
                  <Award size={16} className="text-[#8B5CF6]" />
                </div>
                <h3 className="font-semibold text-white">Certifications & Achievements</h3>
              </div>
            </RevealSection>

            <div className="space-y-4">
              {certifications.map((cert, i) => (
                <RevealSection key={cert.title} direction="right" delay={i * 0.1 + 0.1}>
                  <div className="glass rounded-2xl p-5 border border-white/5 hover:border-[#8B5CF6]/20 transition-all duration-300 group">
                    <div className="flex items-start gap-4">
                      <div className="flex-shrink-0 mt-0.5">
                        <CheckCircle2 size={18} className="text-[#8B5CF6]" />
                      </div>
                      <div>
                        <h4 className="font-semibold text-white text-sm mb-0.5">{cert.title}</h4>
                        <p className="text-xs text-[#8B5CF6] font-mono mb-2">{cert.subtitle}</p>
                        <p className="text-xs text-[#475569] leading-relaxed">{cert.description}</p>
                      </div>
                    </div>
                  </div>
                </RevealSection>
              ))}
            </div>
          </div>
        </div>
      </div>
    </section>
  )
}
