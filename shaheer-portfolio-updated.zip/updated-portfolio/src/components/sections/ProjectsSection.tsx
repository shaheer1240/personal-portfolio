import { useState } from 'react'
import { motion, AnimatePresence } from 'framer-motion'
import { ExternalLink, ChevronDown, ChevronUp, Code2, Target, Lightbulb, TrendingUp, Github, Star } from 'lucide-react'
import SectionHeader from '@/components/ui/SectionHeader'
import RevealSection from '@/components/ui/RevealSection'
import { projects } from '@/data/cv'

function TechBadge({ tech, color }: { tech: string; color: string }) {
  return (
    <span
      className="px-2.5 py-1 text-xs font-mono rounded-lg border"
      style={{ color, borderColor: `${color}30`, background: `${color}10` }}
    >
      {tech}
    </span>
  )
}

function StatusBadge({ status }: { status: string }) {
  if (status === 'in-progress') {
    return (
      <span className="flex items-center gap-1.5 px-2.5 py-1 text-xs font-semibold rounded-full bg-[#F59E0B]/15 text-[#F59E0B] border border-[#F59E0B]/30">
        <span className="w-1.5 h-1.5 rounded-full bg-[#F59E0B] animate-pulse" />
        In Progress
      </span>
    )
  }
  return (
    <span className="flex items-center gap-1.5 px-2.5 py-1 text-xs font-semibold rounded-full bg-[#10B981]/15 text-[#10B981] border border-[#10B981]/30">
      <span className="w-1.5 h-1.5 rounded-full bg-[#10B981]" />
      Completed
    </span>
  )
}

function ProjectCard({ project, index }: { project: typeof projects[0]; index: number }) {
  const [expanded, setExpanded] = useState(false)

  return (
    <RevealSection delay={index * 0.12}>
      <motion.div
        layout
        className="glass rounded-2xl border border-white/5 overflow-hidden group hover:border-white/10 transition-all duration-300"
        style={{ borderTopColor: `${project.color}20` }}
      >
        {/* Header */}
        <div className="p-6 md:p-8">
          <div className="flex items-start justify-between gap-4 mb-4">
            <div className="flex items-center gap-4">
              <div
                className="w-14 h-14 rounded-2xl flex items-center justify-center text-2xl flex-shrink-0"
                style={{ background: `${project.color}15` }}
              >
                {project.icon}
              </div>
              <div>
                <div className="flex items-center gap-2 mb-1">
                  <p className="text-xs font-mono text-[#475569]">{project.subtitle}</p>
                  {project.featured && (
                    <span className="flex items-center gap-1 text-xs text-[#F59E0B] font-semibold">
                      <Star size={10} fill="currentColor" /> Featured
                    </span>
                  )}
                </div>
                <h3 className="text-xl font-bold text-white">{project.title}</h3>
              </div>
            </div>
            <StatusBadge status={project.status} />
          </div>

          <p className="text-[#94A3B8] leading-relaxed mb-5">{project.description}</p>

          {/* Technologies */}
          <div className="flex flex-wrap gap-2 mb-5">
            {project.technologies.map(tech => (
              <TechBadge key={tech} tech={tech} color={project.color} />
            ))}
          </div>

          {/* Features preview */}
          <div className="grid sm:grid-cols-2 gap-2 mb-6">
            {project.features.slice(0, 4).map(feat => (
              <div key={feat} className="flex items-start gap-2 text-sm">
                <div className="w-1.5 h-1.5 rounded-full mt-1.5 flex-shrink-0" style={{ background: project.color }} />
                <span className="text-[#94A3B8]">{feat}</span>
              </div>
            ))}
          </div>

          {/* Actions row */}
          <div className="flex flex-wrap items-center gap-4">
            <button
              onClick={() => setExpanded(v => !v)}
              className="flex items-center gap-2 text-sm font-medium transition-all duration-200 hover:gap-3"
              style={{ color: project.color }}
              aria-expanded={expanded}
            >
              {expanded ? (
                <>Hide Case Study <ChevronUp size={16} /></>
              ) : (
                <>View Full Case Study <ChevronDown size={16} /></>
              )}
            </button>

            <div className="flex items-center gap-3 ml-auto">
              {project.githubUrl && (
                <a
                  href={project.githubUrl}
                  target="_blank"
                  rel="noopener noreferrer"
                  className="flex items-center gap-1.5 text-xs font-medium text-[#475569] hover:text-white transition-colors px-3 py-1.5 glass rounded-lg border border-white/5 hover:border-white/15"
                >
                  <Github size={13} />
                  GitHub
                </a>
              )}
              {project.liveUrl && (
                <a
                  href={project.liveUrl}
                  target="_blank"
                  rel="noopener noreferrer"
                  className="flex items-center gap-1.5 text-xs font-medium transition-colors px-3 py-1.5 rounded-lg border"
                  style={{ color: project.color, borderColor: `${project.color}30`, background: `${project.color}10` }}
                >
                  <ExternalLink size={13} />
                  Live Demo
                </a>
              )}
            </div>
          </div>
        </div>

        {/* Expanded case study */}
        <AnimatePresence>
          {expanded && (
            <motion.div
              initial={{ opacity: 0, height: 0 }}
              animate={{ opacity: 1, height: 'auto' }}
              exit={{ opacity: 0, height: 0 }}
              transition={{ duration: 0.4, ease: [0.22, 1, 0.36, 1] }}
              style={{ borderTopColor: `${project.color}15` }}
              className="border-t border-white/5"
            >
              <div className="p-6 md:p-8 grid md:grid-cols-2 gap-8">
                {/* Problem */}
                <div>
                  <div className="flex items-center gap-2 mb-3">
                    <Target size={16} style={{ color: project.color }} />
                    <h4 className="text-sm font-semibold text-white">Problem Statement</h4>
                  </div>
                  <p className="text-sm text-[#94A3B8] leading-relaxed">{project.problem}</p>
                </div>

                {/* Objectives */}
                <div>
                  <div className="flex items-center gap-2 mb-3">
                    <Code2 size={16} style={{ color: project.color }} />
                    <h4 className="text-sm font-semibold text-white">Objectives</h4>
                  </div>
                  <ul className="space-y-1.5">
                    {project.objectives.map(obj => (
                      <li key={obj} className="flex items-start gap-2 text-sm text-[#94A3B8]">
                        <div className="w-1 h-1 rounded-full mt-2 flex-shrink-0 opacity-60" style={{ background: project.color }} />
                        {obj}
                      </li>
                    ))}
                  </ul>
                </div>

                {/* Challenges */}
                <div>
                  <div className="flex items-center gap-2 mb-3">
                    <Lightbulb size={16} style={{ color: project.color }} />
                    <h4 className="text-sm font-semibold text-white">Challenges & Solutions</h4>
                  </div>
                  <div className="space-y-3">
                    {project.challenges.map((ch, i) => (
                      <div key={ch} className="text-sm">
                        <p className="text-[#94A3B8] mb-1">⚡ {ch}</p>
                        <p className="text-[#475569] pl-4">→ {project.solutions[i]}</p>
                      </div>
                    ))}
                  </div>
                </div>

                {/* Impact */}
                <div>
                  <div className="flex items-center gap-2 mb-3">
                    <TrendingUp size={16} style={{ color: project.color }} />
                    <h4 className="text-sm font-semibold text-white">Key Learnings & Impact</h4>
                  </div>
                  <ul className="space-y-1.5 mb-4">
                    {project.learnings.map(l => (
                      <li key={l} className="flex items-start gap-2 text-sm text-[#94A3B8]">
                        <div className="w-1 h-1 rounded-full mt-2 flex-shrink-0 opacity-60" style={{ background: project.color }} />
                        {l}
                      </li>
                    ))}
                  </ul>
                  <div
                    className="rounded-xl p-4 text-sm leading-relaxed"
                    style={{ background: `${project.color}10`, color: project.color }}
                  >
                    {project.impact}
                  </div>
                </div>
              </div>
            </motion.div>
          )}
        </AnimatePresence>
      </motion.div>
    </RevealSection>
  )
}

export default function ProjectsSection() {
  return (
    <section id="projects" className="section-padding relative" aria-label="Projects">
      <div className="max-w-5xl mx-auto px-6">
        <SectionHeader
          eyebrow="Featured Work"
          title="Projects that tell the story"
          subtitle="Each project was a learning opportunity and a complete, shipped application — not just a tutorial exercise."
        />
        <div className="space-y-6">
          {projects.map((project, i) => (
            <ProjectCard key={project.id} project={project} index={i} />
          ))}
        </div>
      </div>
    </section>
  )
}
