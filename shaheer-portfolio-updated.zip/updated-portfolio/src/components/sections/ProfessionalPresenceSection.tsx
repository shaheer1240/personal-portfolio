import { motion } from 'framer-motion'
import { ExternalLink, Github, Linkedin, Briefcase, Star, GitBranch, Users } from 'lucide-react'
import SectionHeader from '@/components/ui/SectionHeader'
import RevealSection from '@/components/ui/RevealSection'
import { personal } from '@/data/cv'

const presenceCards = [
  {
    id: 'linkedin',
    platform: 'LinkedIn',
    icon: Linkedin,
    color: '#0077B5',
    gradient: 'from-[#0077B5]/20 to-[#0077B5]/5',
    url: personal.linkedin,
    featured: true,
    tagline: 'Professional Network',
    description:
      'Explore my professional journey, technical growth, achievements, and career aspirations. Connect with me to discuss opportunities, collaborations, or just to say hi.',
    highlights: [
      { icon: Users, text: 'Career journey & achievements' },
      { icon: Star, text: 'Skills & endorsements' },
      { icon: Briefcase, text: 'Professional growth' },
    ],
    cta: 'View LinkedIn Profile',
  },
  {
    id: 'github',
    platform: 'GitHub',
    icon: Github,
    color: '#E6EDF3',
    gradient: 'from-white/10 to-white/3',
    url: personal.github,
    featured: false,
    tagline: 'Development Workspace',
    description:
      'GitHub reflects my practical development experience through real-world projects, experimentation, and continuous learning. Browse my repositories and coding journey.',
    highlights: [
      { icon: GitBranch, text: 'Open source projects' },
      { icon: Star, text: 'Coding experiments' },
      { icon: Briefcase, text: 'Active development' },
    ],
    cta: 'Explore My GitHub',
  },
  {
    id: 'indeed',
    platform: 'Indeed',
    icon: Briefcase,
    color: '#2164F3',
    gradient: 'from-[#2164F3]/20 to-[#2164F3]/5',
    url: personal.indeed,
    featured: false,
    tagline: 'Job Profile',
    description:
      'My Indeed profile represents my active career interests, job applications, and professional opportunities. Find my full work preferences and availability here.',
    highlights: [
      { icon: Briefcase, text: 'Active job seeker' },
      { icon: Star, text: 'Open to internships' },
      { icon: Users, text: 'Freelance & entry-level roles' },
    ],
    cta: 'View Indeed Profile',
  },
]

export default function ProfessionalPresenceSection() {
  return (
    <section id="presence" className="section-padding relative" aria-label="Professional presence">
      <div className="max-w-5xl mx-auto px-6">
        <SectionHeader
          eyebrow="Find Me Online"
          title="Professional Presence"
          subtitle="Connect with me across platforms — from professional networking to open source contributions."
          centered
        />

        <div className="grid md:grid-cols-3 gap-6">
          {presenceCards.map((card, i) => {
            const Icon = card.icon
            return (
              <RevealSection key={card.id} delay={i * 0.12}>
                <motion.div
                  whileHover={{ y: -4 }}
                  transition={{ duration: 0.25 }}
                  className={`glass rounded-2xl border overflow-hidden h-full flex flex-col transition-all duration-300 ${
                    card.featured
                      ? 'border-[#0077B5]/30 hover:border-[#0077B5]/50'
                      : 'border-white/5 hover:border-white/15'
                  }`}
                >
                  {/* Card header */}
                  <div className={`bg-gradient-to-br ${card.gradient} p-6 pb-5`}>
                    {card.featured && (
                      <div className="flex items-center gap-1.5 text-xs font-semibold text-[#0077B5] mb-3">
                        <Star size={11} fill="currentColor" /> Featured Profile
                      </div>
                    )}
                    <div className="flex items-center gap-3 mb-3">
                      <div
                        className="w-12 h-12 rounded-xl flex items-center justify-center"
                        style={{ background: `${card.color}20`, border: `1px solid ${card.color}30` }}
                      >
                        <Icon size={22} style={{ color: card.color }} />
                      </div>
                      <div>
                        <h3 className="font-bold text-white text-lg">{card.platform}</h3>
                        <p className="text-xs font-mono" style={{ color: card.color }}>{card.tagline}</p>
                      </div>
                    </div>
                  </div>

                  {/* Card body */}
                  <div className="p-6 flex flex-col flex-1">
                    <p className="text-sm text-[#94A3B8] leading-relaxed mb-5 flex-1">
                      {card.description}
                    </p>

                    <div className="space-y-2 mb-6">
                      {card.highlights.map((h, hi) => {
                        const HIcon = h.icon
                        return (
                          <div key={hi} className="flex items-center gap-2.5 text-xs text-[#475569]">
                            <HIcon size={13} style={{ color: card.color }} />
                            {h.text}
                          </div>
                        )
                      })}
                    </div>

                    <a
                      href={card.url}
                      target="_blank"
                      rel="noopener noreferrer"
                      className="w-full flex items-center justify-center gap-2 py-2.5 rounded-xl text-sm font-semibold transition-all duration-200 hover:scale-[1.02]"
                      style={{
                        background: `${card.color}20`,
                        color: card.color,
                        border: `1px solid ${card.color}30`,
                      }}
                    >
                      {card.cta}
                      <ExternalLink size={14} />
                    </a>
                  </div>
                </motion.div>
              </RevealSection>
            )
          })}
        </div>
      </div>
    </section>
  )
}
