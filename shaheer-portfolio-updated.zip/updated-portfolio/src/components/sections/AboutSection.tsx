import { Code2, Lightbulb, Target, BookOpen, Smartphone, Database } from 'lucide-react'
import SectionHeader from '@/components/ui/SectionHeader'
import RevealSection from '@/components/ui/RevealSection'
import { personal } from '@/data/cv'

const traits = [
  {
    icon: Code2,
    title: 'Full-Stack Focus',
    description: 'From MySQL schemas to responsive UIs — I architect complete, integrated web solutions using ASP.NET MVC, PHP, and JavaScript.',
  },
  {
    icon: Target,
    title: 'Problem-First Thinking',
    description: 'I start with understanding the real problem before writing a single line of code. Every feature has a purpose.',
  },
  {
    icon: Lightbulb,
    title: 'Design-Aware Developer',
    description: 'Trained in Figma and UI/UX principles, I bridge the gap between logic and aesthetics to build intuitive interfaces.',
  },
  {
    icon: Smartphone,
    title: 'Mobile Developer',
    description: 'Currently building cross-platform mobile apps with Flutter and Firebase, expanding beyond the web.',
  },
  {
    icon: Database,
    title: 'Database-Driven Apps',
    description: 'Strong expertise in SQL Server and MySQL — I design efficient, normalized schemas that support scalable applications.',
  },
  {
    icon: BookOpen,
    title: 'Continuous Learner',
    description: 'From Hafiz-e-Quran to Aptech certified developer — discipline and consistency define my approach to mastering new skills.',
  },
]

const stats = [
  { value: '10+', label: 'Projects Built' },
  { value: '5–6', label: 'Client Projects (Innova Tech)' },
  { value: '4+', label: 'Certifications' },
  { value: '∞', label: 'Problems Solved' },
]

export default function AboutSection() {
  return (
    <section id="about" className="section-padding relative" aria-label="About Shaheer">
      <div className="max-w-5xl mx-auto px-6">
        <SectionHeader
          eyebrow="About Me"
          title="The developer behind the code"
        />

        <div className="grid lg:grid-cols-2 gap-16 items-start">
          {/* Story */}
          <div className="space-y-6">
            <RevealSection direction="left">
              <p className="text-[#94A3B8] text-lg leading-relaxed">
                I'm an O-Level student and self-driven developer based in Karachi, Pakistan. My journey into
                software started with a simple goal:{' '}
                <span className="text-white font-medium">build things that actually work</span> — real
                applications that serve real users. That mindset led me through Aptech's rigorous web
                development program and into professional work at Innova Tech.
              </p>
            </RevealSection>
            <RevealSection direction="left" delay={0.1}>
              <p className="text-[#94A3B8] text-lg leading-relaxed">
                At Innova Tech, I contributed to{' '}
                <span className="text-white font-medium">5–6 client and company projects</span> as a PHP
                developer, working within Agile workflows and Git-based version control in a real software
                house environment. Beyond PHP, I've built a{' '}
                <span className="text-white font-medium">talent showcasing platform</span> with ASP.NET MVC,
                a dynamic grocery cart system, and I'm currently developing{' '}
                <span className="text-white font-medium">FocusFlow</span> — a productivity app — and a
                Flutter-based laptop e-commerce mobile app.
              </p>
            </RevealSection>
            <RevealSection direction="left" delay={0.2}>
              <p className="text-[#94A3B8] text-lg leading-relaxed">
                Being a Hafiz-e-Quran taught me that{' '}
                <span className="text-white font-medium">discipline and consistency</span> beat talent
                alone. I bring that same focus to every project. I'm fluent in English and Urdu, which
                helps me collaborate effectively and communicate technical ideas clearly to any audience.
              </p>
            </RevealSection>

            {/* Interests */}
            <RevealSection delay={0.3}>
              <div className="flex flex-wrap gap-2 pt-2">
                {personal.interests.map(interest => (
                  <span
                    key={interest}
                    className="px-3 py-1.5 text-xs font-medium glass rounded-full text-[#94A3B8] border border-white/5"
                  >
                    {interest}
                  </span>
                ))}
              </div>
            </RevealSection>
          </div>

          {/* Right column: stats + traits */}
          <div className="space-y-8">
            {/* Stats */}
            <RevealSection direction="right">
              <div className="grid grid-cols-2 gap-4">
                {stats.map(stat => (
                  <div key={stat.label} className="glass rounded-2xl p-5 border border-white/5 text-center">
                    <div className="text-3xl font-bold gradient-text mb-1">{stat.value}</div>
                    <div className="text-xs text-[#475569] font-medium">{stat.label}</div>
                  </div>
                ))}
              </div>
            </RevealSection>

            {/* Traits */}
            <div className="grid grid-cols-1 gap-3">
              {traits.map((trait, i) => (
                <RevealSection key={trait.title} direction="right" delay={0.08 * i}>
                  <div className="flex gap-4 p-4 glass rounded-xl border border-white/5 group hover:border-[#00D4FF]/20 transition-all duration-300">
                    <div className="flex-shrink-0 w-10 h-10 rounded-lg bg-[#00D4FF]/10 flex items-center justify-center group-hover:bg-[#00D4FF]/20 transition-colors">
                      <trait.icon size={18} className="text-[#00D4FF]" />
                    </div>
                    <div>
                      <div className="text-sm font-semibold text-white mb-0.5">{trait.title}</div>
                      <div className="text-xs text-[#475569] leading-relaxed">{trait.description}</div>
                    </div>
                  </div>
                </RevealSection>
              ))}
            </div>
          </div>
        </div>
      </div>
    </section>
  )
}
