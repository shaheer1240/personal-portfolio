import { scrollToSection } from '@/hooks/useSmoothScroll'
import { personal } from '@/data/cv'

const navLinks = ['About', 'Skills', 'Projects', 'Education', 'Contact']

export default function Footer() {
  return (
    <footer className="border-t border-white/5 py-12" role="contentinfo">
      <div className="max-w-5xl mx-auto px-6">
        <div className="flex flex-col md:flex-row items-center justify-between gap-6">
          <div className="text-center md:text-left">
            <div className="font-mono text-sm font-bold text-[#00D4FF] mb-1">&lt;Shaheer /&gt;</div>
            <p className="text-xs text-[#475569]">Web Developer & UI/UX Designer · Karachi, Pakistan</p>
          </div>

          <nav className="flex items-center gap-6" aria-label="Footer navigation">
            {navLinks.map(link => (
              <button
                key={link}
                onClick={() => scrollToSection(link.toLowerCase())}
                className="text-xs text-[#475569] hover:text-[#94A3B8] transition-colors"
              >
                {link}
              </button>
            ))}
          </nav>

          <div className="text-center md:text-right">
            <a
              href={`mailto:${personal.email}`}
              className="text-xs text-[#475569] hover:text-[#00D4FF] transition-colors"
            >
              {personal.email}
            </a>
            <p className="text-xs text-[#475569] mt-1">
              © {new Date().getFullYear()} Shaheer. All rights reserved.
            </p>
          </div>
        </div>
      </div>
    </footer>
  )
}
