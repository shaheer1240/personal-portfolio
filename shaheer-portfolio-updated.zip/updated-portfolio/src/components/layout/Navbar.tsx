import { useState, useEffect } from 'react'
import { motion, AnimatePresence } from 'framer-motion'
import { Menu, X } from 'lucide-react'
import { scrollToSection } from '@/hooks/useSmoothScroll'

const navLinks = [
  { label: 'About', id: 'about' },
  { label: 'Skills', id: 'skills' },
  { label: 'Projects', id: 'projects' },
  { label: 'Presence', id: 'presence' },
  { label: 'Education', id: 'education' },
  { label: 'Contact', id: 'contact' },
]

export default function Navbar() {
  const [scrolled, setScrolled] = useState(false)
  const [mobileOpen, setMobileOpen] = useState(false)
  const [active, setActive] = useState('')

  useEffect(() => {
    const handleScroll = () => {
      setScrolled(window.scrollY > 40)

      // Update active section
      const sections = navLinks.map(l => document.getElementById(l.id))
      const visible = sections.find(s => {
        if (!s) return false
        const rect = s.getBoundingClientRect()
        return rect.top <= 120 && rect.bottom >= 120
      })
      setActive(visible?.id ?? '')
    }

    window.addEventListener('scroll', handleScroll, { passive: true })
    return () => window.removeEventListener('scroll', handleScroll)
  }, [])

  const handleNav = (id: string) => {
    scrollToSection(id)
    setMobileOpen(false)
  }

  return (
    <>
      <motion.nav
        initial={{ y: -80, opacity: 0 }}
        animate={{ y: 0, opacity: 1 }}
        transition={{ duration: 0.6, delay: 0.2 }}
        className={`fixed top-0 left-0 right-0 z-50 transition-all duration-300 ${
          scrolled ? 'py-3' : 'py-5'
        }`}
      >
        <div
          className={`mx-4 md:mx-auto md:max-w-5xl rounded-2xl transition-all duration-300 ${
            scrolled ? 'glass px-6 py-3' : 'px-2 py-0'
          }`}
        >
          <div className="flex items-center justify-between">
            {/* Logo */}
            <button
              onClick={() => scrollToSection('hero')}
              className="font-mono text-sm font-semibold tracking-wider text-[#00D4FF] hover:opacity-80 transition-opacity"
              aria-label="Back to top"
            >
              &lt;Shaheer /&gt;
            </button>

            {/* Desktop Links */}
            <div className="hidden md:flex items-center gap-1">
              {navLinks.map(link => (
                <button
                  key={link.id}
                  onClick={() => handleNav(link.id)}
                  className={`relative px-4 py-2 text-sm font-medium rounded-lg transition-all duration-200 group ${
                    active === link.id
                      ? 'text-[#00D4FF]'
                      : 'text-[#94A3B8] hover:text-white'
                  }`}
                >
                  {active === link.id && (
                    <motion.div
                      layoutId="nav-pill"
                      className="absolute inset-0 bg-[#00D4FF]/10 rounded-lg border border-[#00D4FF]/20"
                    />
                  )}
                  <span className="relative z-10">{link.label}</span>
                </button>
              ))}
            </div>

            {/* CTA */}
            <div className="hidden md:flex items-center gap-3">
              <button
                onClick={() => handleNav('contact')}
                className="px-4 py-2 text-sm font-medium bg-[#00D4FF] text-[#080B14] rounded-lg hover:bg-[#00D4FF]/90 transition-all duration-200 font-semibold"
              >
                Hire Me
              </button>
            </div>

            {/* Mobile menu button */}
            <button
              className="md:hidden p-2 text-[#94A3B8] hover:text-white transition-colors"
              onClick={() => setMobileOpen(v => !v)}
              aria-label={mobileOpen ? 'Close menu' : 'Open menu'}
            >
              {mobileOpen ? <X size={20} /> : <Menu size={20} />}
            </button>
          </div>
        </div>
      </motion.nav>

      {/* Mobile Menu */}
      <AnimatePresence>
        {mobileOpen && (
          <motion.div
            initial={{ opacity: 0, y: -10 }}
            animate={{ opacity: 1, y: 0 }}
            exit={{ opacity: 0, y: -10 }}
            transition={{ duration: 0.2 }}
            className="fixed inset-x-4 top-20 z-40 glass-strong rounded-2xl p-6"
          >
            <nav className="flex flex-col gap-1">
              {navLinks.map(link => (
                <button
                  key={link.id}
                  onClick={() => handleNav(link.id)}
                  className={`text-left px-4 py-3 rounded-lg text-sm font-medium transition-all ${
                    active === link.id
                      ? 'text-[#00D4FF] bg-[#00D4FF]/10'
                      : 'text-[#94A3B8] hover:text-white hover:bg-white/5'
                  }`}
                >
                  {link.label}
                </button>
              ))}
              <button
                onClick={() => handleNav('contact')}
                className="mt-2 px-4 py-3 text-sm font-semibold bg-[#00D4FF] text-[#080B14] rounded-lg"
              >
                Hire Me
              </button>
            </nav>
          </motion.div>
        )}
      </AnimatePresence>
    </>
  )
}
